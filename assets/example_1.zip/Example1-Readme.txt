Synthetic, single-sounding, DIGHEM-style data-sets. Each
directory "invalgXY" contains the results of an example
inversion using algorithm X and model type Y.
