Line of synthetic 3D data over two conductive & susceptibile
prisms. This is the data-set for the third example in the
Examples section at the end of the Manual.
